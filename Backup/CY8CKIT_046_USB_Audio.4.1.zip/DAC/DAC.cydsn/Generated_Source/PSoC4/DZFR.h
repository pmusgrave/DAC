/*******************************************************************************
* File Name: DZFR.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DZFR_H) /* Pins DZFR_H */
#define CY_PINS_DZFR_H

#include "cytypes.h"
#include "cyfitter.h"
#include "DZFR_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} DZFR_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   DZFR_Read(void);
void    DZFR_Write(uint8 value);
uint8   DZFR_ReadDataReg(void);
#if defined(DZFR__PC) || (CY_PSOC4_4200L) 
    void    DZFR_SetDriveMode(uint8 mode);
#endif
void    DZFR_SetInterruptMode(uint16 position, uint16 mode);
uint8   DZFR_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void DZFR_Sleep(void); 
void DZFR_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(DZFR__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define DZFR_DRIVE_MODE_BITS        (3)
    #define DZFR_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - DZFR_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the DZFR_SetDriveMode() function.
         *  @{
         */
        #define DZFR_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define DZFR_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define DZFR_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define DZFR_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define DZFR_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define DZFR_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define DZFR_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define DZFR_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define DZFR_MASK               DZFR__MASK
#define DZFR_SHIFT              DZFR__SHIFT
#define DZFR_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DZFR_SetInterruptMode() function.
     *  @{
     */
        #define DZFR_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define DZFR_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define DZFR_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define DZFR_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(DZFR__SIO)
    #define DZFR_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(DZFR__PC) && (CY_PSOC4_4200L)
    #define DZFR_USBIO_ENABLE               ((uint32)0x80000000u)
    #define DZFR_USBIO_DISABLE              ((uint32)(~DZFR_USBIO_ENABLE))
    #define DZFR_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define DZFR_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define DZFR_USBIO_ENTER_SLEEP          ((uint32)((1u << DZFR_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << DZFR_USBIO_SUSPEND_DEL_SHIFT)))
    #define DZFR_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << DZFR_USBIO_SUSPEND_SHIFT)))
    #define DZFR_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << DZFR_USBIO_SUSPEND_DEL_SHIFT)))
    #define DZFR_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(DZFR__PC)
    /* Port Configuration */
    #define DZFR_PC                 (* (reg32 *) DZFR__PC)
#endif
/* Pin State */
#define DZFR_PS                     (* (reg32 *) DZFR__PS)
/* Data Register */
#define DZFR_DR                     (* (reg32 *) DZFR__DR)
/* Input Buffer Disable Override */
#define DZFR_INP_DIS                (* (reg32 *) DZFR__PC2)

/* Interrupt configuration Registers */
#define DZFR_INTCFG                 (* (reg32 *) DZFR__INTCFG)
#define DZFR_INTSTAT                (* (reg32 *) DZFR__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define DZFR_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(DZFR__SIO)
    #define DZFR_SIO_REG            (* (reg32 *) DZFR__SIO)
#endif /* (DZFR__SIO_CFG) */

/* USBIO registers */
#if !defined(DZFR__PC) && (CY_PSOC4_4200L)
    #define DZFR_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define DZFR_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define DZFR_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define DZFR_DRIVE_MODE_SHIFT       (0x00u)
#define DZFR_DRIVE_MODE_MASK        (0x07u << DZFR_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins DZFR_H */


/* [] END OF FILE */
