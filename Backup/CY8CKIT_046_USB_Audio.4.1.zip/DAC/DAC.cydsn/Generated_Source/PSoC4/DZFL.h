/*******************************************************************************
* File Name: DZFL.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DZFL_H) /* Pins DZFL_H */
#define CY_PINS_DZFL_H

#include "cytypes.h"
#include "cyfitter.h"
#include "DZFL_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} DZFL_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   DZFL_Read(void);
void    DZFL_Write(uint8 value);
uint8   DZFL_ReadDataReg(void);
#if defined(DZFL__PC) || (CY_PSOC4_4200L) 
    void    DZFL_SetDriveMode(uint8 mode);
#endif
void    DZFL_SetInterruptMode(uint16 position, uint16 mode);
uint8   DZFL_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void DZFL_Sleep(void); 
void DZFL_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(DZFL__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define DZFL_DRIVE_MODE_BITS        (3)
    #define DZFL_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - DZFL_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the DZFL_SetDriveMode() function.
         *  @{
         */
        #define DZFL_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define DZFL_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define DZFL_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define DZFL_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define DZFL_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define DZFL_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define DZFL_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define DZFL_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define DZFL_MASK               DZFL__MASK
#define DZFL_SHIFT              DZFL__SHIFT
#define DZFL_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DZFL_SetInterruptMode() function.
     *  @{
     */
        #define DZFL_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define DZFL_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define DZFL_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define DZFL_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(DZFL__SIO)
    #define DZFL_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(DZFL__PC) && (CY_PSOC4_4200L)
    #define DZFL_USBIO_ENABLE               ((uint32)0x80000000u)
    #define DZFL_USBIO_DISABLE              ((uint32)(~DZFL_USBIO_ENABLE))
    #define DZFL_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define DZFL_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define DZFL_USBIO_ENTER_SLEEP          ((uint32)((1u << DZFL_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << DZFL_USBIO_SUSPEND_DEL_SHIFT)))
    #define DZFL_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << DZFL_USBIO_SUSPEND_SHIFT)))
    #define DZFL_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << DZFL_USBIO_SUSPEND_DEL_SHIFT)))
    #define DZFL_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(DZFL__PC)
    /* Port Configuration */
    #define DZFL_PC                 (* (reg32 *) DZFL__PC)
#endif
/* Pin State */
#define DZFL_PS                     (* (reg32 *) DZFL__PS)
/* Data Register */
#define DZFL_DR                     (* (reg32 *) DZFL__DR)
/* Input Buffer Disable Override */
#define DZFL_INP_DIS                (* (reg32 *) DZFL__PC2)

/* Interrupt configuration Registers */
#define DZFL_INTCFG                 (* (reg32 *) DZFL__INTCFG)
#define DZFL_INTSTAT                (* (reg32 *) DZFL__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define DZFL_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(DZFL__SIO)
    #define DZFL_SIO_REG            (* (reg32 *) DZFL__SIO)
#endif /* (DZFL__SIO_CFG) */

/* USBIO registers */
#if !defined(DZFL__PC) && (CY_PSOC4_4200L)
    #define DZFL_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define DZFL_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define DZFL_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define DZFL_DRIVE_MODE_SHIFT       (0x00u)
#define DZFL_DRIVE_MODE_MASK        (0x07u << DZFL_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins DZFL_H */


/* [] END OF FILE */
