/*******************************************************************************
* File Name: MCLK.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MCLK_H) /* Pins MCLK_H */
#define CY_PINS_MCLK_H

#include "cytypes.h"
#include "cyfitter.h"
#include "MCLK_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} MCLK_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   MCLK_Read(void);
void    MCLK_Write(uint8 value);
uint8   MCLK_ReadDataReg(void);
#if defined(MCLK__PC) || (CY_PSOC4_4200L) 
    void    MCLK_SetDriveMode(uint8 mode);
#endif
void    MCLK_SetInterruptMode(uint16 position, uint16 mode);
uint8   MCLK_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void MCLK_Sleep(void); 
void MCLK_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(MCLK__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define MCLK_DRIVE_MODE_BITS        (3)
    #define MCLK_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - MCLK_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the MCLK_SetDriveMode() function.
         *  @{
         */
        #define MCLK_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define MCLK_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define MCLK_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define MCLK_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define MCLK_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define MCLK_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define MCLK_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define MCLK_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define MCLK_MASK               MCLK__MASK
#define MCLK_SHIFT              MCLK__SHIFT
#define MCLK_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in MCLK_SetInterruptMode() function.
     *  @{
     */
        #define MCLK_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define MCLK_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define MCLK_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define MCLK_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(MCLK__SIO)
    #define MCLK_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(MCLK__PC) && (CY_PSOC4_4200L)
    #define MCLK_USBIO_ENABLE               ((uint32)0x80000000u)
    #define MCLK_USBIO_DISABLE              ((uint32)(~MCLK_USBIO_ENABLE))
    #define MCLK_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define MCLK_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define MCLK_USBIO_ENTER_SLEEP          ((uint32)((1u << MCLK_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << MCLK_USBIO_SUSPEND_DEL_SHIFT)))
    #define MCLK_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << MCLK_USBIO_SUSPEND_SHIFT)))
    #define MCLK_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << MCLK_USBIO_SUSPEND_DEL_SHIFT)))
    #define MCLK_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(MCLK__PC)
    /* Port Configuration */
    #define MCLK_PC                 (* (reg32 *) MCLK__PC)
#endif
/* Pin State */
#define MCLK_PS                     (* (reg32 *) MCLK__PS)
/* Data Register */
#define MCLK_DR                     (* (reg32 *) MCLK__DR)
/* Input Buffer Disable Override */
#define MCLK_INP_DIS                (* (reg32 *) MCLK__PC2)

/* Interrupt configuration Registers */
#define MCLK_INTCFG                 (* (reg32 *) MCLK__INTCFG)
#define MCLK_INTSTAT                (* (reg32 *) MCLK__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define MCLK_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(MCLK__SIO)
    #define MCLK_SIO_REG            (* (reg32 *) MCLK__SIO)
#endif /* (MCLK__SIO_CFG) */

/* USBIO registers */
#if !defined(MCLK__PC) && (CY_PSOC4_4200L)
    #define MCLK_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define MCLK_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define MCLK_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define MCLK_DRIVE_MODE_SHIFT       (0x00u)
#define MCLK_DRIVE_MODE_MASK        (0x07u << MCLK_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins MCLK_H */


/* [] END OF FILE */
