/*******************************************************************************
* File Name: CSN.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "CSN.h"

static CSN_BACKUP_STRUCT  CSN_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: CSN_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function applies only to SIO and USBIO pins.
*  It should not be called for GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet CSN_SUT.c usage_CSN_Sleep_Wakeup
*******************************************************************************/
void CSN_Sleep(void)
{
    #if defined(CSN__PC)
        CSN_backup.pcState = CSN_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            CSN_backup.usbState = CSN_CR1_REG;
            CSN_USB_POWER_REG |= CSN_USBIO_ENTER_SLEEP;
            CSN_CR1_REG &= CSN_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(CSN__SIO)
        CSN_backup.sioState = CSN_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        CSN_SIO_REG &= (uint32)(~CSN_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: CSN_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep(). This 
* function applies only to SIO and USBIO pins. It should not be called for
* GPIO or GPIO_OVT pins.
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to CSN_Sleep() for an example usage.
*******************************************************************************/
void CSN_Wakeup(void)
{
    #if defined(CSN__PC)
        CSN_PC = CSN_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            CSN_USB_POWER_REG &= CSN_USBIO_EXIT_SLEEP_PH1;
            CSN_CR1_REG = CSN_backup.usbState;
            CSN_USB_POWER_REG &= CSN_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(CSN__SIO)
        CSN_SIO_REG = CSN_backup.sioState;
    #endif
}


/* [] END OF FILE */
