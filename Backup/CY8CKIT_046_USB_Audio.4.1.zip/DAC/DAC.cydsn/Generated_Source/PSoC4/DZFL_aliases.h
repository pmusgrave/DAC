/*******************************************************************************
* File Name: DZFL.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DZFL_ALIASES_H) /* Pins DZFL_ALIASES_H */
#define CY_PINS_DZFL_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define DZFL_0			(DZFL__0__PC)
#define DZFL_0_PS		(DZFL__0__PS)
#define DZFL_0_PC		(DZFL__0__PC)
#define DZFL_0_DR		(DZFL__0__DR)
#define DZFL_0_SHIFT	(DZFL__0__SHIFT)
#define DZFL_0_INTR	((uint16)((uint16)0x0003u << (DZFL__0__SHIFT*2u)))

#define DZFL_INTR_ALL	 ((uint16)(DZFL_0_INTR))


#endif /* End Pins DZFL_ALIASES_H */


/* [] END OF FILE */
