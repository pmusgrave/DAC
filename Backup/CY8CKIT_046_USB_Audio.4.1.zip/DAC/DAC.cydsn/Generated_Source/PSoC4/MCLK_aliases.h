/*******************************************************************************
* File Name: MCLK.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MCLK_ALIASES_H) /* Pins MCLK_ALIASES_H */
#define CY_PINS_MCLK_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define MCLK_0			(MCLK__0__PC)
#define MCLK_0_PS		(MCLK__0__PS)
#define MCLK_0_PC		(MCLK__0__PC)
#define MCLK_0_DR		(MCLK__0__DR)
#define MCLK_0_SHIFT	(MCLK__0__SHIFT)
#define MCLK_0_INTR	((uint16)((uint16)0x0003u << (MCLK__0__SHIFT*2u)))

#define MCLK_INTR_ALL	 ((uint16)(MCLK_0_INTR))


#endif /* End Pins MCLK_ALIASES_H */


/* [] END OF FILE */
